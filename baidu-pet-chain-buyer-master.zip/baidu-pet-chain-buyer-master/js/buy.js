/*
 * @author t@tabalt.net
 */

$(function(){
	Buyer.ShowPetsOnSale();
    setInterval(function(){
		if(Buyer.pageNo === 0) Buyer.pageNo = 70;
        Buyer.ShowPetsOnSale();
    }, 1000);

    Buyer.InitBuyModal();

    /*setInterval(function(){
        Buyer.TryBuyPets();
    }, 200);*/
});