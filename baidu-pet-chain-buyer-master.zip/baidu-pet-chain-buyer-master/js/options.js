/*
 * @author t@tabalt.net
 */

$(function(){
    Configurator.displayDegreeConf(); 
    Configurator.saveDegreeConf(); 
});