/*
 * @author t@tabalt.net
 */

$(function(){
    // Icons Init
    feather.replace();
});


