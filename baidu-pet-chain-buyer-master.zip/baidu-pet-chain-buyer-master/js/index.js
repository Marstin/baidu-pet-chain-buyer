/*
 * @author t@tabalt.net
 */

$(function(){
    window.location.href = 'buy.html'
});