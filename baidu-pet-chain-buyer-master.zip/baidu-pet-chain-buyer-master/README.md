# baidu-pet-chain-buyer

<p>百度莱茨狗抢购插件</p>

### 使用文档

https://github.com/playwithblockchain/baidu-pet-chain-buyer/wiki

### 打赏支持

<p>打赏支持作者持续开发完善</p>
<p><img src="images/wechatpay.png" /></p>

### 联系作者

<p>关注作者公众号</p>
<p><img src="images/wechat-qrcode.jpg" width="128" height="128" /></p>

### 版本更新

* 2018-02-22 2.1版发布，新增提前打码功能、新增多处提示、优化体验等
* 2018-02-09 2.0版发布，全新界面化，支持手动输入验证码
* 2018-02-05 支持配置买入价格
* 2018-02-04 首次发布&开源
